/*----------------------------------------------------------------------------*/
/* Xymon WML generator.                                                       */
/*                                                                            */
/* Copyright (C) 2002-2011 Henrik Storner <henrik@storner.dk>                 */
/*                                                                            */
/* This program is released under the GNU General Public License (GPL),       */
/* version 2. See the file "COPYING" for details.                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

#ifndef __WMLGEN_H__
#define __WMLGEN_H__

extern int enable_wmlgen;
extern void do_wml_cards(char *webdir);

#endif

