/*----------------------------------------------------------------------------*/
/* Xymon monitor                                                              */
/*                                                                            */
/* Copyright (C) 2002-2015 Henrik Storner <henrik@storner.dk>                 */
/*                                                                            */
/* This program is released under the GNU General Public License (GPL),       */
/* version 2. See the file "COPYING" for details.                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

#ifndef __VERSION_H__
#define __VERSION_H__

#define VERSION "4.3.28"

#endif

